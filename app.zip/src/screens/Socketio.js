import React, { useEffect } from "react";
import { View, Text } from "react-native";
// import io from "socket.io-client";

const Socketio = () => {
  return (
    <View>
      <Text>Your React Native Component</Text>
    </View>
  );
};

export default Socketio;
