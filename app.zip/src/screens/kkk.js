import { StyleSheet, Text, TouchableHighlight, View } from 'react-native'
import React from 'react'
import { SafeAreaView } from 'react-native-safe-area-context'
import { TouchableOpacity } from 'react-native-gesture-handler'
import RazorpayCheckout from 'react-native-razorpay';
const kkk = () => {

  return (
    <SafeAreaView  >
      <Text styles={{marginTop:100}}>kkk</Text>
      <TouchableOpacity onPress={()=>{}} >
        <Text>Pay</Text>
      </TouchableOpacity>


     
    </SafeAreaView>
  )
}

export default kkk

const styles = StyleSheet.create({})