// export const base_url = "http://3.111.23.56:5059/api";
export const base_url = "https://quiz.metablocktechnologies.org/api";


// export const base_url = "http://192.168.1.16:5050/api";
