export function FormatDateTime(){
    const milliseconds = 1642958701000; // Example timestamp in milliseconds
    const formattedDateTime = convertMillisecondsToDateTime(milliseconds);
    console.log(formattedDateTime);
return formattedDateTime
}

