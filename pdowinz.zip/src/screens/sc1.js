import { View, Text } from 'react-native'
import React from 'react'

const sc1 = () => {
  return (
    <View>
      <Text>sc1</Text>
    </View>
  )
}

export default sc1